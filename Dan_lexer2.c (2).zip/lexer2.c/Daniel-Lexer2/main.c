/*Main.c
author: Daniel Perez
Date: 02/2021
Class- Compiler theory
Descirption:will reapetedly call lexeruntil the end of the file
*/

#include "Atto-c.h"

main()
{
    int next_tok;
    do
    {
        next_tok = lexer();
        printf("Token %d\n", next_tok);
    } while (next_tok != EOF_TOK);
    exit(0);
}