/* lexer.c

A simple lexical analyzer for integers and decimal fractions.

Author: Ken Brakke
Date: Jan. 26, 2017
Edited by:Daniel Perez 02/01


A Finite State machine is used to recognize strings consisting of digits
followed by a decimal point followed by digits.  There must be at least
one digit before the decimal point.  The decimal point and digits after
the decimal point are optional.  Characters not part of legal tokens
will cause a REJECT message, and the lexer will move on to the next
token.

Note: The FINAL state here does not refer to any particular node of the
FSM.  It is used after each true "final" state to signal the lexical
analyzer to start a new token.

Usage: Launch.  A console window will appear.  You may type in strings
followed by ENTER, and they will either be accepted by the Finite State
Machine and print ACCEPT, or not and print REJECT.  The token type and
lexeme (the characters of the token) will also be printed.  Multiple
numbers may be entered on one line.  To exit the program, hit CTRL-Z and
ENTER.

*/

#include "Atto-c.h"  // header file


// Finite State Machine states
#define START    1
#define INTEGER   2
#define DEC_FRAC  3
#define IDENT     5
#define LEFT_PAR_State  6
#define RIGHT_PAR_State 7
#define COMMA_STATE   8
#define SEMICOLON_STATE 9
#define LEFT_BRAK_STATE 10
#define RIGHT_BRAK_STATE 11
#define SUBTRACTION_STATE 12
#define NOT_STATE		13
#define MULTIPICATION	14
#define DIVISION_STATE	15
#define ADDITION_STATE	16
#define LESS_THAN_EQ	17
#define GREATER_THAN_EQ 18
#define LESS_THAN		19
#define GREATER_THAN	20
#define DOUBLEQUAL		21
#define EQUAL			22
#define NOT_EQUAL		23
#define WHITESPACE		24
#define OR				25
#define AND				26
#define IDENT			27
#define STRING_START	35
#define STRING_END		29
#define FINAL			 4
#define LINE_COM		30
#define BLOK_COM_START	31
#define BLOK_COM_END	32
#define BLOK_COM_STAR	33
#define BLACK_SLASH		34
#define NEWLINE_STATE	35




// Special look-ahead character value to indicate none 
#define NO_CHAR 0
int line_no = 1; // Line number in current input file
int next_char;  // The next character of input.
char lexeme[MAX_LEXEME]; // The characters of the token

#define KEYWORDS_MAX 28

char* keywords[KEYWORDS_MAX] = { "auto", "break", "case", "char", "continue", "default", "do", "double", "else", "enum", "extern", "float", "for", "goto", "if", 
"int", "long", "register", "return", "short", "sizeof", "static", "struct", "switch", "typedef", "union", "unsigned", "while" };

int keyword_tokens[KEYWORDS_MAX] = { AUTO_TOK, BREAK_TOK,CASE_TOK,CAHR_TOK,CONTINUE_TOK,DEFAULT_TOK,DO_TOK,DOUBLE_TOK,	ELSE_TOK,ENUM_TOK,EXTERN_TOK,FLOAT_TOK,FOR_TOK,GOTO_TOK,IF_TOK, 
INT_TOK,LONG_TOK,REGISTER_TOK,REUTRN_TOK,SHORT_TOK,SIZEOF_TOK,STATIC_TOK,STRUCT_TOK,SWITCH_TOK,TYPEDEF_TOK,UNION_TOK,UNSIGNED_TOK,WHILE_TOK};

int lexer()
{
	int state;   // The current state of the FSM.
	int lex_spot; // Current spot in lexeme.
	int token_type;  // The type of token found.
					 // Infinite loop, doing one token at a time.
	while (1)
	{  // Initialize the Finite State Machine.
		state = START;
		lex_spot = 0;
		while (state != FINAL)
		{
			if (next_char == NO_CHAR)
				next_char = getc(stdin);  // get one character from standard input

			switch (state)
			{
			case START:

				if (next_char == EOF)
					return EOF_TOK;// exit the preogram withe the exit code0, which is success
				else if(next_char == '\n')  // just eat the newline and stay in START
				{
					line_no++;
					next_char = NO_CHAR;
				}
				else if (isdigit(next_char))
				{
					state = INTEGER;
					lexeme[lex_spot++] = next_char;  // Add the character to the lexeme
					next_char = NO_CHAR;  // eat the character
				}
				else if (next_char== ' ')
				{
					state = WHITESPACE;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else if (next_char=='(')
				{
					state = LEFT_PAR_State;
					lexeme[lex_spot++] = next_char;  // Add the character to the lexeme
					next_char = NO_CHAR;  // eat the character
				}
				else if (next_char == ')')
				{
					state = RIGHT_PAR_State;
					lexeme[lex_spot++] = next_char;  // Add the character to the lexeme
					next_char = NO_CHAR;  // eat the character
				}
				else if (next_char == ',')
				{
					state = COMMA_STATE;
					lexeme[lex_spot++] = next_char;  // Add the character to the lexeme
					next_char = NO_CHAR;  // eat the character
				}
				else if (next_char == ';')
				{
					state = SEMICOLON_STATE;
					lexeme[lex_spot++] = next_char;  // Add the character to the lexeme
					next_char = NO_CHAR;  // eat the character
				}
				else if (next_char == '{')
				{
					state = LEFT_BRAK_STATE;
					lexeme[lex_spot++] = next_char;  // Add the character to the lexeme
					next_char = NO_CHAR;  // eat the character				
				}
				else if (next_char == '}')
				{
					state = RIGHT_BRAK_STATE;
					lexeme[lex_spot++] = next_char;  // Add the character to the lexeme
					next_char = NO_CHAR;  // eat the character
				}
				else if (next_char == '-')
				{
					state = SUBTRACTION_STATE;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;  // eat the character
				}
				else if (next_char == '*')
				{
					state = MULTIPICATION;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else if (next_char == '/')
				{
					state = DIVISION_STATE;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else if (next_char == '!')
				{
					state = NOT_STATE;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else if (next_char == '+')
				{
					state = ADDITION_STATE;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else if (next_char == '<')
				{
					state = LESS_THAN;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else if (next_char == '>')
				{
					state = GREATER_THAN;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else if (next_char == '=')
				{
					state = EQUAL;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else if (next_char=='"')
				{
					state = STRING_START;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else if (isalpha(next_char)||next_char=='_')
				{
					state = IDENT;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else if (next_char == '|')
				{
					state = OR;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else if (next_char == '&')
				{
					state = AND;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}	
				else if (next_char=='\n')
				{
				state = NEWLINE_STATE;
				lexeme[lex_spot++] = next_char;
				next_char = NO_CHAR;
				}
				else
				{
					printf("REJECT %c at line %d\n", next_char, line_no);
					state = FINAL;  // but we want to end the token anyway
					next_char = NO_CHAR;   // eat the offending character
				}
				break;  // Need "break" at the end of a case, else you will continue to the next case.
/*_______________________________________________________________________cases______________________________________________________________________________________________________________*/
			case WHITESPACE:
				{
					lexeme[lex_spot] = 0;
					token_type = WHITESPACE_TOK;
					printf("ACCEPT WHITESPACE %s token type %d\n", lexeme, token_type); 
					state = FINAL;
					return token_type;
					
				}
			break;
			case LEFT_PAR_State:
				{	
					lexeme[lex_spot] = 0;
					token_type = Left_Par_TOK;
					printf("ACCEPT LEFT_PAR_State%s token type %d\n", lexeme, token_type);//this is final state 
					state = FINAL;
				}
				break;
			case RIGHT_PAR_State:
				{	
				lexeme[lex_spot] = 0;
				token_type = Right_Par_TOK;
				printf("ACCEPT RIGHT_PAR_State%s token type %d\n", lexeme, token_type);//this is final state 
				state = FINAL;
				}
			break;
			case COMMA_STATE:
			{
				lexeme[lex_spot] = 0;
				token_type = COMMA_TOK;
				printf("ACCEPT COMMA_STATE%s token type %d\n", lexeme, token_type);//this is final state 
				state = FINAL;
			}
			break;
			case SEMICOLON_STATE:
			{
				lexeme[lex_spot] = 0;
				token_type = SEMICOLON_TOK;
				printf("ACCEPT SEMICOLON_STATE%s token type %d\n", lexeme, token_type);//this is final state 
				state = FINAL;
			}
			break;
			case LEFT_BRAK_STATE:
			{
				lexeme[lex_spot] = 0;
				token_type = Left_BRAK_TOK;
				printf("ACCEPT LEFT_BRAK_STATE%s token type %d\n", lexeme, token_type);//this is final state 
				state = FINAL;
			}
			break;
			case RIGHT_BRAK_STATE:
			{
				lexeme[lex_spot] = 0;
				token_type = Right_BRAK_TOK;
				printf("ACCEPT RIGHT_BRAK_STATE%s token type %d\n", lexeme, token_type);//this is final state 
				state = FINAL;
			}
			break;
			case SUBTRACTION_STATE:
			{
				lexeme[lex_spot] = 0;
				token_type = SUBTRACTION_TOK;
				printf("ACCEPT SUBTRACTION %s token type %d\n", lexeme, token_type);
				state = FINAL;
			}
			break;
			case NOT_STATE:
				if (next_char == '!')
				{
					state = NOT_STATE;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else if (next_char == '=')
				{
					state = NOT_EQUAL;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else
				{
					lexeme[lex_spot] = 0; // null for end of string
					token_type = IDENT_TOK;
					printf("ACCEPT NOT_STATE %s token type %d\n", lexeme, token_type);  // This is a final state
					state = FINAL;       // leave next_char alone, for next token
				}
			break;
			case NOT_EQUAL:				
			{
				lexeme[lex_spot] = 0;
				token_type = NOT_EQUAL_TOK;
				printf("ACCEPT NOT_EQUAL %s token type %d\n", lexeme, token_type);
				state = FINAL;
			}
			break;
			case MULTIPICATION:
				if (next_char == '/')
				{
					state = BLOK_COM_END;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else
				{
					lexeme[lex_spot] = 0;
					token_type = MULTIPLICATION_TOK;
					printf("ACCEPT MUTIPLICATION %s token type %d\n", lexeme, token_type);
					state = FINAL;
				}
				break;
			case DIVISION_STATE:
				if (next_char == '/')
				{
					state = LINE_COM;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else if (next_char == '*')
				{
					state = BLOK_COM_START;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else
				{
					lexeme[lex_spot] = 0; // null for end of string
					token_type = DIVISION_TOK;
					printf("ACCEPT DIVISION %s token type %d\n", lexeme, token_type);  // This is a final state
					state = FINAL;       // leave next_char alone, for next token
				}
				break;
			case LINE_COM:
				if (next_char!='\n')
				{
				 state = LINE_COM;				 
				 next_char = NO_CHAR;
				}
				else
				{
					lexeme[lex_spot] = 0; // null for end of string
					token_type = LINE_COM_TOK;
					printf("ACCEPT LINE COMMENT %s token type %d\n", lexeme, token_type);  // This is a final state
					state = FINAL;
					line_no++;
					return token_type;
			    }
			break;
			case BLOK_COM_START:
				if (next_char == EOF)
				{
					printf("REJECT end-of-file in quote , line%d\n", line_no);
					exit(1);
				}
				if (next_char == '\n')
				{
					line_no++;
				}
				if (next_char!='*')
				{
					state = BLOK_COM_START;
					next_char = NO_CHAR;
				}
				else if (next_char=='*')
				{
					state = BLOK_COM_STAR;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
			break;
			case BLOK_COM_STAR:
			if (next_char == '\n')
			{
				line_no++;
			}
			if (next_char == '/')
			{
				state = BLOK_COM_END;
				lexeme[lex_spot++] = next_char;
				next_char = NO_CHAR;
			}
			else if (next_char == '*')
			{
				state = BLOK_COM_START;
				lexeme[lex_spot++] = next_char;
				next_char = NO_CHAR;
			}
			break;
			
			case BLOK_COM_END:
			{
				lexeme[lex_spot] = 0;
				token_type = BLOK_COM_TOK;
				printf("ACCEPT BLOCK COMMENT TOKEN %s token type %d\n", lexeme, token_type);
				state = FINAL;
				return token_type;
			}
			break;

			case ADDITION_STATE:
				{
					lexeme[lex_spot] = 0;
					token_type =ADDITION_TOK ;
					printf("ACCEPT ADDITION %s token type %d\n", lexeme, token_type);
					state = FINAL;
				}
			break;
			case LESS_THAN:
				if (next_char=='<')
				{
					state = LESS_THAN;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else if (next_char=='=')
				{
					state = LESS_THAN_EQ;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else
				{
					lexeme[lex_spot] = 0; // null for end of string
					token_type = IDENT_TOK;
					printf("ACCEPT LESS_THAN %s token type %d\n", lexeme, token_type);  // This is a final state
					state = FINAL;       // leave next_char alone, for next token
				}
			break;
			case GREATER_THAN:
				if (next_char == '>')
				{
					state = GREATER_THAN;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else if (next_char == '=')
				{
					state = GREATER_THAN_EQ;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else
				{
					lexeme[lex_spot] = 0; // null for end of string
					token_type = IDENT_TOK;
					printf("ACCEPT GREATER_THAN %s token type %d\n", lexeme, token_type);  // This is a final state
					state = FINAL;       // leave next_char alone, for next token
				}
			break;
			case LESS_THAN_EQ:
		
				lexeme[lex_spot] = 0;
				token_type = LESS_EQ_TOK;
				printf("ACCEPT LESS THAN EQUAL TO %s token type %d\n", lexeme, token_type);
				state = FINAL;
				break;

			case GREATER_THAN_EQ:

				lexeme[lex_spot] = 0;
				token_type = GREATER_EQ_TOK;
				printf("ACCEPT GREATER THAN EQUAL TO %s token type %d\n", lexeme, token_type);
				state = FINAL;
				break;

			case DOUBLEQUAL:
			{
				lexeme[lex_spot] = 0;
				token_type = DOUBLE_EQ_TOK;
				printf("ACCEPT DOUBLE EQUAL %s token type %d\n", lexeme, token_type);
				state = FINAL;
			}
			break;

			case EQUAL:
				if (next_char == '=')
				{
					state = DOUBLEQUAL;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else
				{
					lexeme[lex_spot] = 0; // null for end of string
					token_type = IDENT_TOK;
					printf("ACCEPT EQUAL %s token type %d\n", lexeme, token_type);  // This is a final state
					state = FINAL;       // leave next_char alone, for next token
				}
			break;
			case OR:
				if (next_char == '|')
				{
					state = OR;
					lexeme[lex_spot++] = next_char;
					next_char =  NO_CHAR;
				}
				else
				{
					lexeme[lex_spot] = 0; // null for end of string
					token_type = OR_TOK;
					printf("ACCEPT OR %s token type %d\n", lexeme, token_type);  // This is a final state
					state = FINAL;       // leave next_char alone, for next token
				}
			break;
			case AND:
				if (next_char == '&')
				{
					state = AND;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else
				{
					lexeme[lex_spot] = 0; // null for end of string
					token_type = AND_TOK;
					printf("ACCEPT AND %s token type %d\n", lexeme, token_type);  // This is a final state
					state = FINAL;       // leave next_char alone, for next token
				}
			break;
			case IDENT:
				if (isalpha(next_char)||next_char=='_')
				{
					if (lex_spot == IDENT_MAX_LENGTH)
					{
						printf("ERROR: identifier too long. Truncating. Line %d\n", line_no);
						lexeme[lex_spot++] = 0;
					}
					else if (lex_spot < IDENT_MAX_LENGTH)
						lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else
				{
					int k; 
					state = FINAL;
					lexeme[lex_spot] = 0; // null for end of string
					token_type = IDENT_TOK;
					for (k = 0; k < KEYWORDS_MAX; k++)
					{
						if (strcmp(lexeme, keywords[k]) == 0) 
						{ 
							token_type = keyword_tokens[k];
						}
					}
					if (token_type == IDENT_TOK)
						printf("ACCEPT IDENTIFIER: %s, token type: %d \n", lexeme, token_type);  // This is a final state
					else
						printf("ACCEPT KEYWORD: %s, token type: %d \n", lexeme, token_type);  // This is a final state
					return token_type;
				}
				break;

			case INTEGER:
				if (isdigit(next_char))
				{
					state = INTEGER;
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else
				{
					lexeme[lex_spot] = 0; // null for end of string
					token_type = INTEGER_TOK;
					printf("ACCEPT INTEGER %s token type %d\n", lexeme, token_type);  // This is a final state
					state = FINAL;       // leave next_char alone, for next token
					return token_type;
				}
				if (lex_spot < NUMBER_MAX_LENGTH)
				{
					printf("Error: nu8mber too long. truncation. line%d\n",line_no);
					lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				else if (lex_spot < NUMBER_MAX_LENGTH)
					lexeme[lex_spot++] = next_char;
				next_char = NO_CHAR;
				break;

			case STRING_START:
				if (next_char==EOF)
				{
					printf("Reject and of file string, line %d\n", line_no);
					exit(1);
				}
				if (next_char == '\n')
				{
					printf("Reject  newline in quote, line%d\n", line_no);
					state = FINAL;
					next_char = NO_CHAR;
					line_no++;
				}
				else if (next_char == '"')
				{
					lexeme[lex_spot++] = next_char;
					lexeme[lex_spot++] = 0; // Null for end of string
					token_type = STRING_TOK;
					printf("ACCEPT STRING: %s, token type: %d \n", lexeme, token_type);  // This is a final state
					state = FINAL;       // leave next_char alone, for next token
					next_char = NO_CHAR;
					return token_type;
				}
				else if (next_char == '\\')
				{
					state = BLACK_SLASH;
					next_char = NO_CHAR;
				}
				else
				{
					
					if (lex_spot==MAX_LEXEME-3)
					{
						printf("ERROR: quoted string too liong . Truncating. line %d\n",line_no);
						lexeme[lex_spot++] = next_char;
					}
					else if (lex_spot < MAX_LEXEME - 3)
						lexeme[lex_spot++] = next_char;
					next_char = NO_CHAR;
				}
				break;
			case BLACK_SLASH:
				if (next_char == EOF)
				{
					printf("REJECT end-of-file in quote , line%d\n",line_no);
					exit(1);
				}
				if (next_char == '\n')
				{
					printf("Reject new line in string, line %d\n", line_no);
					state = FINAL;
					next_char = NO_CHAR;
					line_no++;
				}
				else if (next_char == 'n')
					lexeme[lex_spot++] = '\n';
				else if (next_char == 'b')
					lexeme[lex_spot++] = '\b';
				else if (next_char == 't')
					lexeme[lex_spot++] = '\t';
				else if (next_char == '"')
					lexeme[lex_spot++] = '"';
				else if (next_char == '\\')
					lexeme[lex_spot++] = '\\';
				else
					lexeme[lex_spot++] = next_char;
				next_char = 0;
				state = STRING_START;
				break;

			case STRING_END:
			
				lexeme[lex_spot] = 0; // 
				token_type = STRING_TOK;
				printf("ACCEPT STRING %s token type %d\n", lexeme, token_type);  // This is a final state
				state = FINAL;
				next_char = NO_CHAR;
				return token_type;
				
				break;
			default:
				printf("INTERNAL ERROR: Illegal state %d\n", state);
				state = FINAL;
				break;

			} // end of switch

		} // end of while state

	}  // end of infinite loop

	return 0;  // successful exit code
} // end of main
