 #pragma once
/* lexer.c

A simple lexical analyzer for integers and decimal fractions.

Author: Daniel Perez
Date: 02/09

A Finite State machine is used to recognize strings consisting of digits
followed by  characrters or different orders of operations. Characters not part of legal tokens
will cause a REJECT message, and the lexer will move on to the next
token.

Note: The FINAL state here does not refer to any particular node of the
FSM.  It is used after each true "final" state to signal the lexical
analyzer to start a new token.

Usage: Launch.  A console window will appear.  You may type in strings
followed by ENTER, and they will either be accepted by the Finite State
Machine and print ACCEPT, or not and print REJECT.  The token type and
lexeme (the characters of the token) will also be printed.  Multiple
numbers may be entered on one line.  To exit the program, hit CTRL-Z and
ENTER.

*/

#include <stdio.h>    // standard input-output declarations: printf, stdin
#include <stdlib.h>   // standard library declarations: exit
#include <ctype.h>    // character type test declarations:  isdigit, isalpha, isalnum
#include <string.h>


// Token types
#define INTEGER_TOK          101
#define DECIMAL_FRACTION_TOK 102
#define Left_Par_TOK		 103
#define Right_Par_TOK		 104
#define COMMA_TOK			 105
#define SEMICOLON_TOK		 106
#define Left_BRAK_TOK		 107
#define Right_BRAK_TOK		 108
#define WHITESPACE_TOK		 109
#define SUBTRACTION_TOK		 110
#define NOT_TOK				 111
#define MULTIPLICATION_TOK	 112
#define DIVISION_TOK		 113
#define GREATER_THAN_TOK	 114
#define LESS_THAN_TOK	  	 115
#define GREATER_EQ_TOK	 	 116
#define LESS_EQ_TOK			 117
#define DOUBLE_EQ_TOK		 118
#define EQUAL_TOK			 119
#define NOT_EQUAL_TOK		 120
#define OR_TOK				 121
#define AND_TOK				 122
#define IDENT_TOK			 123
#define STRING_TOK			 124
#define ADDITION_TOK		 125
#define LINE_COM_TOK	 	 126
#define BLOK_COM_TOK		 127
#define AUTO_TOK		 	 128
#define BREAK_TOK			 129
#define CASE_TOK			 130
#define CAHR_TOK			 131
#define CONTINUE_TOK		 132
#define DEFAULT_TOK			 133
#define DO_TOK				 134
#define DOUBLE_TOK			 135
#define ELSE_TOK			 136
#define ENUM_TOK			 137
#define EXTERN_TOK			 138
#define FLOAT_TOK			 139
#define FOR_TOK				 140
#define GOTO_TOK			 141
#define IF_TOK				 142
#define INT_TOK				 143
#define LONG_TOK			 144
#define REGISTER_TOK		 145
#define REUTRN_TOK			 146
#define SHORT_TOK			 147
#define SIZEOF_TOK			 148
#define STATIC_TOK			 149
#define STRUCT_TOK			 150
#define SWITCH_TOK			 151
#define TYPEDEF_TOK			 152
#define UNION_TOK			 153
#define UNSIGNED_TOK		 154
#define WHILE_TOK			 155
#define EOF_TOK				 156



extern int line_no; // Line number in current input file

#define MAX_LEXEME 200
extern char lexeme[MAX_LEXEME]; // The characters of the token
#define IDENT_MAX_LENGTH 50
#define NUMBER_MAX_LENGTH 10

int lexer(void);