// this is a small anagram finder, you must insert a few words to start
import java.util.ArrayList;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Anagrams 
{
	// This String possibleAnagrams stores the anagrams of the input words by the User. it is a global String
	static List<String> possibleAnagrams = new ArrayList<String>();
	
	static List<String> realWords = new ArrayList<String>();
	

	public static void main(String[] args) throws FileNotFoundException 
		
	    {
		//Function allows the program to prompt the user for input
	       String[] userInput = getUserWords();
	       //print the user input As an array of elements
	       System.out.println( Arrays.toString(userInput));
	       
	       // We have to find the combinations of the letters of the user input to form differennt tokens
	       for(int i =0; i< userInput.length; i++)
	       {
	    	      findAnagrams(userInput[i], "");
	       }
	       System.out.println("All Possible combinations: "+(possibleAnagrams));
	       
	     Scanner oxford_dict = new Scanner(new FileInputStream("C:\\Users\\tiku\\Desktop\\SPRING 2021\\Anagram finding game\\oxford_words.txt"));
	  ArrayList<String> wordsoxford = new ArrayList<String>();
	  // work through all the words in oxford dictionary words.
	  while(oxford_dict.hasNextLine()) {
		  // add strings from the oxf file  to words that will be used to compare the user anagrams
		  wordsoxford.add(oxford_dict.nextLine());
		  
	  }
	  //close the oxford dictionary
	  oxford_dict.close();
	  
	  String[] stringarray = possibleAnagrams.toArray(new String[0]);
	  
	  String[] Stringsdict = wordsoxford.toArray(new String[0]);
	  
	  isRealWords(stringarray, Stringsdict);
	  
	  System.out.println("");
	  System.out.println("All meaningful anagrams of the above in the Oxford Dictionary: ");
	  System.out.println(realWords);
	  

	}
	
	// Function gets input from user on a line and prints it out as an array of single words
	public static String[] getUserWords()
	{
		// Here we prompt the user for an input is a list of words on a line
		Scanner scanner = new Scanner(System.in);
        System.out.println("Put your input words fro the anagram in a line");
       
       //Now we store the user input as an array of elements
            String[] tokens = scanner.nextLine().split("\\s");
            //prints out user input as an array
            System.out.println("Input words array " );           
        //close the scanner
        scanner.close();
        return tokens;
        
	}
	 
	static void findAnagrams(String str, String result)
	{
		// when the string is empty, like a white space or when we are done iterating on the words
		if (str.length() == 0)
		{
			possibleAnagrams.add(result);
			return;
		}
		
		for (int i =0; i < str.length(); i++)
		{
			//we find some character in the word
			char ch = str.charAt(i);
			//We find the rest of the string after taking away the other character
			String restOfStr = str.substring(0, i) + str.substring(i+1);
			findAnagrams(restOfStr, result + ch);
		}
	}

	static void isRealWords(String[] userInput, String[] oxf)
	 {
		// This loops iterates and swaps the letters in the words of the User input.
		for(int i = 0; i<userInput.length; i++)
		 {
			// Second for loop iterates through the words in the oxford words file and compares them.
			for(int j = 0; j<oxf.length; j++) 
			{
				// Now, we compare if the user input words can be found in the oxford file
				if(userInput[i].equalsIgnoreCase(oxf[j])) 
				{
					realWords.add(userInput[i]);
				}
			}

	     }
	  
	}
}
