/* lexer.c

   A simple lexical analyzer for integers and decimal fractions.

   Author: Robel Wondwossen
   Date: February, 19, 2021

   A Finite State machine is used to recognize strings consisting of digits
   followed by a decimal point followed by digits. Characters are now part 
   of legal tokens and will return token types. Errors that may be caused by 
   either reachin the Lexeme limit(MAX_LEXEME) will cause a REJECT message, 
   and the lexer will display an error message.

 */

#include "atto-C.h"   // Header File

 // Finite State Machine states
#define START        1
#define INTEGER      2
#define DEC_FRAC     3
#define FINAL        4
#define COMMA_STATE           5
#define SEMI_COLON_STATE      6
#define LEFT_PAR_STATE        7
#define RIGHT_PAR_STATE       8
#define CURLY_BRACKET_RIGHT_STATE  9
#define CURLY_BRACKET_LEFT_STATE   10
#define ADDITION_BINOP_STATE       11
#define SUBSTRACTION_BINOP_STATE   12
#define MULTIPLICATION_STATE       13
#define DIVISION_BINOP_STATE       14
#define BITWISE_AND_STATE          15
#define LOGICAL_AND_STATE          16
#define BITWISE_OR_STATE           17
#define LOGICAL_OR_STATE           18
#define LESSER_THAN_BINOP_STATE        19
#define GREATER_THAN_BINOP_STATE       20
#define LESSER_THAN_OR_EQUAL_TO_STATE  21
#define GREATER_THAN_OR_EQUAL_TO_STATE 22
#define ASSIGNMENT_STATE           23
#define COMPARISON_BINOP_STATE     24
#define DIFFERENT_BINOP_STATE      25
#define NOT_EQUAL_BINOP_STATE      26
#define IDENTIFIER_STATE           27
#define COMMENT_OUT_START_STATE    30
#define COMMENT_OUT_STAR_STATE     31
#define WHITESPACE_STATE           32
#define NEWLINE_STATE              33
#define STRING_TEST_STATE          34
#define DITTO_TEST_STATE           35
#define LINE_COMMENT_STATE         36
#define COMMENT_OUT_END_STATE      37
#define BACKSLASH_STATE            38


// Special look-ahead character value to indicate none
#define NO_CHAR 0

int line_no = 1; // Line number in current input file
int next_char;  // The next character of input.

char lexeme[MAX_LEXEME]; // The characters of the token

#define KEYWORDS_MAX               28

char* keywords[KEYWORDS_MAX] = { "if", "else", "auto", "break", "case", "char", "continue", "default", "do", "double", "enum", "extern", "float", "for", "goto", "while", "int",
"long", "register", "return", "short", "sizeof", "static", "struct", "switch", "typedef", "union", "unsigned"};

int keyword_tokens[KEYWORDS_MAX] = { IF_TOK, ELSE_TOK, AUTO_TOK, BREAK_TOK, CASE_TOK, CHAR_TOK, CONTINUE_TOK, DEFAULT_TOK, DO_TOK, DOUBLE_TOK, ENUM_TOK, EXTERN_TOK, FLOAT_TOK, FOR_TOK, GOTO_TOK, WHILE_TOK, INT_TOK,
LONG_TOK, REGISTER_TOK, RETURN_TOK, SHORT_TOK, SIZEOF_TOK, STATIC_TOK, STRUCT_TOK, SWITCH_TOK, TYPEDEF_TOK, UNION_TOK, UNSIGNED_TOK };


int lexer()
{
    int state;   // The current state of the FSM.
    int lex_spot; // Current spot in lexeme.
    int token_type;  // The type of token found.

    while (1) // Infinite loop, doing one token at a time.
    {  // Initialize the Finite State Machine.
        state = START;
        lex_spot = 0;
        // Loop over characters of the token.
        while (state != FINAL)
        {
            if (next_char == NO_CHAR)
                next_char = getc(stdin);  // get one character from standard input

            switch (state)
            {
            case START:
                if (next_char == EOF) // EOF is a special character for End-Of-File
                    return EOF_TOK;   // Exit the program with exit code 0
                else if (next_char == '\n')  // just eat the newline and stay in START
                {
                    line_no++;
                    next_char = 0;
                }
                else if (next_char == '_' || isalpha(next_char))
                {
                    state = IDENTIFIER_STATE;
                    lexeme[lex_spot++] = next_char;
                    next_char = NO_CHAR;
                }
                else if (isdigit(next_char))
                {
                    state = INTEGER;
                    lexeme[lex_spot++] = next_char;  // Add the character to the lexeme
                    next_char = NO_CHAR;  // eat the character
                }
                else if (next_char == ',')
                {
                    state = COMMA_STATE;
                    lexeme[lex_spot++] = next_char; //add the character o the lexeme
                    next_char = NO_CHAR; // eat the character
                }
                else if (next_char == ';')
                {
                    state = SEMI_COLON_STATE;
                    lexeme[lex_spot++] = next_char; //add the character o the lexeme
                    next_char = NO_CHAR; // eat the character
                }
                else if (next_char == '(')
                {
                    state = LEFT_PAR_STATE;
                    lexeme[lex_spot++] = next_char; //add the character o the lexeme
                    next_char = NO_CHAR; // eat the character
                }
                else if (next_char == ')')
                {
                    state = RIGHT_PAR_STATE;
                    lexeme[lex_spot++] = next_char; //add the character o the lexeme
                    next_char = NO_CHAR; // eat the character
                }
                else if (next_char == '+')
                {
                    state = ADDITION_BINOP_STATE;
                    lexeme[lex_spot++] = next_char; //add the character o the lexeme
                    next_char = NO_CHAR; // eat the character
                }
                else if (next_char == '-')
                {
                    state = SUBSTRACTION_BINOP_STATE;
                    lexeme[lex_spot++] = next_char; //add the character o the lexeme
                    next_char = NO_CHAR; // eat the character
                }
                else if (next_char == '*')
                {
                    state = MULTIPLICATION_STATE;
                    lexeme[lex_spot++] = next_char; //add the character o the lexeme
                    next_char = NO_CHAR; // eat the character
                }
                else if (next_char == '}')
                {
                    state = CURLY_BRACKET_RIGHT_STATE;
                    lexeme[lex_spot++] = next_char; //add the character o the lexeme
                    next_char = NO_CHAR; // eat the character
                }
                else if (next_char == '{')
                {
                    state = CURLY_BRACKET_LEFT_STATE;
                    lexeme[lex_spot++] = next_char; //add the character o the lexeme
                    next_char = NO_CHAR; // eat the character
                }
                else if (next_char == '{')
                {
                    state = CURLY_BRACKET_LEFT_STATE;
                    lexeme[lex_spot++] = next_char; //add the character o the lexeme
                    next_char = NO_CHAR; // eat the character
                }
                else if (next_char == '>')
                {
                    state = GREATER_THAN_BINOP_STATE;
                    lexeme[lex_spot++] = next_char; //add the character o the lexeme
                    next_char = NO_CHAR; // eat the character
                }
                else if (next_char == '<')
                {
                    state = LESSER_THAN_BINOP_STATE;
                    lexeme[lex_spot++] = next_char; //add the character o the lexeme
                    next_char = NO_CHAR; // eat the character
                }
                else if (next_char == '=')
                {
                    state = ASSIGNMENT_STATE;
                    lexeme[lex_spot++] = next_char; //add the character o the lexeme
                    next_char = NO_CHAR; // eat the character
                }
                else if (next_char == '/')
                {
                    state = DIVISION_BINOP_STATE;
                    lexeme[lex_spot++] = next_char; //add the character o the lexeme
                    next_char = NO_CHAR; // eat the character
                }
                else if (next_char == '!')
                {
                    state = DIFFERENT_BINOP_STATE;
                    lexeme[lex_spot++] = next_char; //add the character o the lexeme
                    next_char = NO_CHAR; // eat the character
                }
                else if (next_char == '&')
                {
                    state = BITWISE_AND_STATE;
                    lexeme[lex_spot++] = next_char; //add the character o the lexeme
                    next_char = NO_CHAR; // eat the character
                }
                else if (next_char == '|')
                {
                    state = BITWISE_OR_STATE;
                    lexeme[lex_spot++] = next_char; //add the character o the lexeme
                    next_char = NO_CHAR; // eat the character
                }
                else if (next_char == ' ')
                {
                    state = WHITESPACE_STATE;
                    lexeme[lex_spot++] = next_char;
                    next_char = NO_CHAR;
                }
                else if (next_char == '"')
                {
                    state = STRING_TEST_STATE;
                    lexeme[lex_spot++] = next_char;
                    next_char = NO_CHAR;
                }
                else if (next_char == ' \n')
                {
                    state = NEWLINE_STATE;
                    lexeme[lex_spot++] = next_char;
                    next_char = NO_CHAR;
                }
                else
                {
                    printf("REJECT %c at line %d\n", next_char, line_no);  // This is not a legal final state
                    state = FINAL;  // but we want to end the token anyway
                    next_char = NO_CHAR;   // eat the offending character
                }
                break;  // Need "break" at the end of a case, else you will continue to the next case.

/*-------------------------------------------------------------------------------------------Cases-------------------------------------------------------------------------*/
            case INTEGER:
                if (isdigit(next_char))
                {
                    state = INTEGER;
                    lexeme[lex_spot++] = next_char;
                    next_char = NO_CHAR;
                }
                else
                {
                    lexeme[lex_spot] = 0; // null for end of string
                    token_type = INTEGER_TOK;
                    printf("ACCEPT INTEGER: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                    state = FINAL;       // leave next_char alone, for next token
                    return token_type;
                }
                if (lex_spot == NUMBER_MAX_LENGTH)
                {
                    printf("ERROR: number too long. Truncating. Line %d\n", line_no);
                    lexeme[lex_spot++] = 0;
                }
                else if (lex_spot < NUMBER_MAX_LENGTH)
                    lexeme[lex_spot++] = next_char;
                next_char = NO_CHAR;
                break;

            case STRING_TEST_STATE:
                if (next_char == EOF)
                {
                    printf("REJECT End-Of-File in quote, at line %d\n", line_no);  // This is not a legal final state
                    exit(1); // Exit program with nonzero exit code for error
                }
                if (next_char == '\n')
                {
                    printf("REJECT NewLine in quote, at line %d\n", line_no);  // This is not a legal final state
                    state = FINAL;  // but we want to end the token anyway
                    next_char = NO_CHAR;   // eat the offending character
                    line_no++;
                }
                else if (next_char == '"')
                {
                    lexeme[lex_spot++] = next_char;
                    lexeme[lex_spot++] = 0; // Null for end of string
                    token_type = STRING_TEST_TOK;
                    printf("ACCEPT STRING: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                    state = FINAL;       // leave next_char alone, for next token
                    next_char = NO_CHAR;
                    return token_type; 
                }
                else if (next_char == '\\')
                {
                    state = BACKSLASH_STATE;
                    next_char = NO_CHAR;
                }
                else
                {
                    if (lex_spot == MAX_LEXEME - 3)
                    {
                        printf("ERROR: Quoted string is too long. Truncating, at line %d\n", line_no);  // This is not a legal final state
                        lexeme[lex_spot++] = next_char;
                    }
                    else if (lex_spot < MAX_LEXEME - 3)
                        lexeme[lex_spot++] = next_char;
                    next_char = NO_CHAR;
                }
                break;

            case BACKSLASH_STATE:
                if (next_char == EOF)
                {
                    printf("REJECT End-Of-File in quote, at line %d\n", line_no);  // This is not a legal final state
                    exit(1); // Exit program with nonzero exit code for error
                }

                if (next_char == '\n')
                {
                    printf("REJECT NewLine in quote, at line %d\n", line_no);  // This is not a legal final state
                    state = FINAL;  // but we want to end the token anyway
                    next_char = 0;   // eat the offending character
                    line_no++;
                }

                else if (next_char == 'n')
                    lexeme[lex_spot++] = '\n';
                else if (next_char == 'b')
                    lexeme[lex_spot++] = '\b';
                else if (next_char == 't')
                    lexeme[lex_spot++] = '\t';
                else if (next_char == '"')
                    lexeme[lex_spot++] = '"';
                else if (next_char == '\\')
                    lexeme[lex_spot++] = '\\';
                else
                    lexeme[lex_spot++] = next_char;
                next_char = 0;
                state = STRING_TEST_STATE;
                break;


            case WHITESPACE_STATE:
            {
                lexeme[lex_spot] = 0; // null for end of string
                token_type = WHITESPACE_TOK;
                printf("ACCEPT WHITESPACE: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                state = FINAL;       // leave next_char alone, for next token
                return token_type;
            }
            break;

            case COMMA_STATE:
            {
                lexeme[lex_spot] = 0; // null for end of string
                token_type = COMMA_TOK;
                printf("ACCEPT COMMA: %s token type: %d \n", lexeme, token_type);  // This is a final state
                state = FINAL;       // leave next_char alone, for next token
                return token_type;
            }
            break;

            case SEMI_COLON_STATE:
            {
                lexeme[lex_spot] = 0; // null for end of string
                token_type = SEMI_COLON_TOK;
                printf("ACCEPT SEMI COLON: %s token type: %d \n", lexeme, token_type);  // This is a final state
                state = FINAL;       // leave next_char alone, for next token
                return token_type;
            }
            break;

            case LEFT_PAR_STATE:
            {
                lexeme[lex_spot] = 0; // null for end of string
                token_type = LEFT_PAR_TOK;
                printf("ACCEPT LEFT_PARAN_STATE: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                state = FINAL;       // leave next_char alone, for next token
                return token_type;
            }
            break;

            case RIGHT_PAR_STATE:
            {
                lexeme[lex_spot] = 0; // null for end of string
                token_type = RIGHT_PAR_TOK;
                printf("ACCEPT RIGHT_PARAN_STATE: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                state = FINAL;       // leave next_char alone, for next token
                return token_type;
            }
            break;

            case ADDITION_BINOP_STATE:
            {
                lexeme[lex_spot] = 0; // null for end of string
                token_type = ADDITION_BINOP_TOK;
                printf("ACCEPT ADDITION: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                state = FINAL;       // leave next_char alone, for next token
                return token_type;
            }
            break;

            case SUBSTRACTION_BINOP_STATE:
            {
                lexeme[lex_spot] = 0; // null for end of string
                token_type = SUBSTRACTION_BINOP_TOK;
                printf("ACCEPT SUBSTRACTION: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                state = FINAL;       // leave next_char alone, for next token
                return token_type;
            }
            break;

            case MULTIPLICATION_STATE:
                if (next_char == '/')
                {
                    state = COMMENT_OUT_STAR_STATE;
                    lexeme[lex_spot++] = next_char;
                    next_char = NO_CHAR;     // leave next_char alone, for next token
                }
                else
                {
                    lexeme[lex_spot] = 0; // null for end of string
                    token_type = MULTIPLICATION_TOK;
                    printf("ACCEPT MULTIPLICATION: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                    state = FINAL;       // leave next_char alone, for next token
                    return token_type;
                }
                break;

            case DIVISION_BINOP_STATE:
                if (next_char == '/')
                {
                    state = LINE_COMMENT_STATE;
                    lexeme[lex_spot++] = next_char;
                    next_char = NO_CHAR;     // leave next_char alone, for next token
                }
                else if (next_char == '*')
                {
                    state = COMMENT_OUT_START_STATE;
                    lexeme[lex_spot++] = next_char;
                    next_char = NO_CHAR;     // leave next_char alone, for next token
                }
                else
                {
                    lexeme[lex_spot] = 0; // null for end of string
                    token_type = DIVISION_BINOP_TOK;
                    printf("ACCEPT DIVISION: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                    state = FINAL;       // leave next_char alone, for next token
                    return token_type;
                }
                break;

            case LINE_COMMENT_STATE:
                if (next_char != '\n')
                {
                    state = LINE_COMMENT_STATE;
                    next_char = NO_CHAR;     // leave next_char alone, for next token
                }
                else
                {
                    lexeme[lex_spot] = 0; // null for end of string
                    token_type = LINE_COMMENT_TOK;
                    printf("ACCEPT LINE COMMENT OUT: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                    state = FINAL;       // leave next_char alone, for next token
                    line_no++;
                    return token_type;
                }
                break;

            case COMMENT_OUT_START_STATE:
                if (next_char == EOF)
                {
                    printf("REJECT End-Of-File in Comment, at line %d\n", line_no);  // This is not a legal final state
                    exit(1); // Exit program with nonzero exit code for error
                }
                if (next_char == '\n')
                {
                    line_no++;
                }
                if (next_char != '*')
                {
                    state = COMMENT_OUT_START_STATE;
                    next_char = NO_CHAR;     // leave next_char alone, for next token
                }
                else if (next_char == '*')
                {
                    state = COMMENT_OUT_STAR_STATE;
                    lexeme[lex_spot++] = next_char;
                    next_char = NO_CHAR;     // leave next_char alone, for next token
                }
                break;

            case COMMENT_OUT_STAR_STATE:
                if (next_char == '\n')
                {
                    line_no++;
                }
                if (next_char == '/')
                {
                    state = COMMENT_OUT_END_STATE;
                    lexeme[lex_spot++] = next_char;
                    next_char = NO_CHAR;     // leave next_char alone, for next token
                }
                else if (next_char == '*')
                {
                    state = COMMENT_OUT_START_STATE;
                    lexeme[lex_spot++] = next_char;
                    next_char = NO_CHAR;     // leave next_char alone, for next token
                }
                break;

            case COMMENT_OUT_END_STATE:
            {
                lexeme[lex_spot] = 0; // null for end of string
                token_type = COMMENT_OUT_TOK;
                printf("ACCEPT COMMENT OUT: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                state = FINAL;       // leave next_char alone, for next token
                return token_type;
            }
            break;

            case BITWISE_AND_STATE:
                if (next_char == '&')
                {
                    state = LOGICAL_AND_STATE;
                    lexeme[lex_spot++] = next_char;
                    next_char = NO_CHAR;     // leave next_char alone, for next token
                }
                else
                {
                    lexeme[lex_spot] = 0; // null for end of string
                    token_type = BITWISE_AND_STATE;
                    printf("ACCEPT BITWISE AND OPERATOR: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                    state = FINAL;       // leave next_char alone, for next token
                    return token_type;
                }
                break;

            case LOGICAL_AND_STATE:
            {
                lexeme[lex_spot] = 0; // null for end of string
                token_type = LOGICAL_AND_TOK;
                printf("ACCEPT LOGICAL AND OPERATOR: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                state = FINAL;       // leave next_char alone, for next token
                return token_type;
            }
            break;

            case BITWISE_OR_STATE:
                if (next_char == '|')
                {
                    state = LOGICAL_OR_STATE;
                    lexeme[lex_spot++] = next_char;
                    next_char = NO_CHAR;     // leave next_char alone, for next token
                }
                else
                {
                    lexeme[lex_spot] = 0; // null for end of string
                    token_type = BITWISE_OR_STATE;
                    printf("ACCEPT BITWISE OR OPERATOR: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                    state = FINAL;       // leave next_char alone, for next token
                    return token_type;
                }
                break;

            case LOGICAL_OR_STATE:
            {
                lexeme[lex_spot] = 0; // null for end of string
                token_type = LOGICAL_OR_TOK;
                printf("ACCEPT LOGICAL OR OPERATOR: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                state = FINAL;       // leave next_char alone, for next token
                return token_type;
            }
            break;

            case CURLY_BRACKET_LEFT_STATE:
            {
                lexeme[lex_spot] = 0; // null for end of string
                token_type = CURLY_BRACKET_LEFT_TOK;
                printf("ACCEPT CURLY BRACKET LEFT: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                state = FINAL;       // leave next_char alone, for next token
                return token_type;
            }
            break;


            case CURLY_BRACKET_RIGHT_STATE:
            {
                lexeme[lex_spot] = 0; // null for end of string
                token_type = CURLY_BRACKET_RIGHT_TOK;
                printf("ACCEPT CURLY BRACKET RIGHT: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                state = FINAL;       // leave next_char alone, for next token
                return token_type;
            }
            break;

            case GREATER_THAN_BINOP_STATE:
                if (next_char == '>')
                {
                    lexeme[lex_spot] = 0; // null for end of string
                    token_type = GREATER_THAN_BINOP_TOK;
                    printf("ACCEPT GREATER THAN: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                    state = FINAL;       // leave next_char alone, for next token
                    return token_type;
                }
                else if (next_char == '=')
                {
                    state = GREATER_THAN_OR_EQUAL_TO_STATE;
                    lexeme[lex_spot++] = next_char;
                    next_char = NO_CHAR;
                }
                else
                {
                    lexeme[lex_spot] = 0; // null for end of string
                    token_type = GREATER_THAN_BINOP_TOK;
                    printf("ACCEPT GREATER THAN: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                    state = FINAL;       // leave next_char alone, for next token
                    return token_type;
                }
                break;

            case LESSER_THAN_BINOP_STATE:
                if (next_char == '<')
                {
                    lexeme[lex_spot] = 0; // null for end of string
                    token_type = LESSER_THAN_BINOP_TOK;
                    printf("ACCEPT LESSER THAN: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                    state = FINAL;       // leave next_char alone, for next token
                    return token_type;
                }
                else if (next_char == '=')
                {
                    state = LESSER_THAN_OR_EQUAL_TO_STATE;
                    lexeme[lex_spot++] = next_char;
                    next_char = NO_CHAR;
                }
                else
                {
                    lexeme[lex_spot] = 0; // null for end of string
                    token_type = LESSER_THAN_BINOP_TOK;
                    printf("ACCEPT LESSER THAN: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                    state = FINAL;       // leave next_char alone, for next token
                    return token_type;
                }
                break;


            case ASSIGNMENT_STATE:
                if (next_char == '=')
                {
                    state = COMPARISON_BINOP_STATE;
                    lexeme[lex_spot++] = next_char;
                    next_char = NO_CHAR;
                }
                else
                {
                    lexeme[lex_spot] = 0; // null for end of string
                    token_type = ASSIGNMENT_TOK;
                    printf("ACCEPT ASSIGNMENT: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                    state = FINAL;       // leave next_char alone, for next token
                    return token_type;
                }
                break;

            case DIFFERENT_BINOP_STATE:
                if (next_char == '=')
                {
                    state = NOT_EQUAL_BINOP_STATE;
                    lexeme[lex_spot++] = next_char;
                    next_char = NO_CHAR;
                }
                else
                {
                    lexeme[lex_spot] = 0; // null for end of string
                    token_type = DIFFERENT_BINOP_TOK;
                    printf("ACCEPT DIFFERENT: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                    state = FINAL;       // leave next_char alone, for next token
                    return token_type;
                }
                break;

            case NOT_EQUAL_BINOP_STATE:
            {
                lexeme[lex_spot] = 0; // null for end of string
                token_type = NOT_EQUAL_BINOP_TOK;
                printf("ACCEPT NOT EQUAL: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                state = FINAL;       // leave next_char alone, for next token
                return token_type;
            }
            break;

            case COMPARISON_BINOP_STATE:
            {
                lexeme[lex_spot] = 0; // null for end of string
                token_type = COMPARISON_BINOP_TOK;
                printf("ACCEPT COMPARISON: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                state = FINAL;       // leave next_char alone, for next token
                return token_type;
            }
            break;

            case IDENTIFIER_STATE:
                if (isalpha(next_char) || next_char == '_')
                {
                    if (lex_spot == IDENT_MAX_LENGTH)
                    {
                        printf("ERROR: identifier too long. Truncating. Line %d\n", line_no);
                        lexeme[lex_spot++] = 0;
                    }
                    else if (lex_spot < IDENT_MAX_LENGTH)
                        lexeme[lex_spot++] = next_char;
                    next_char = NO_CHAR;
                }
                else
                {
                    int k;
                    state = FINAL;
                    lexeme[lex_spot] = 0; //null for end of string
                    token_type = IDENTIFIER_TOK;
                    for (k = 0; k < KEYWORDS_MAX; k++)
                    {
                        if (strcmp(lexeme, keywords[k]) == 0)
                        {
                            token_type = keyword_tokens[k];
                            break;
                        }
                    }
                    if (token_type == IDENTIFIER_TOK)
                        printf("ACCEPT IDENTIFIER: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                    else
                        printf("ACCEPT KEYWORD: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                    return token_type;
                }
                break;

            case LESSER_THAN_OR_EQUAL_TO_STATE:
                if (next_char == '=')
                {
                    state = LESSER_THAN_OR_EQUAL_TO_STATE;
                    lexeme[lex_spot++] = next_char;
                    next_char = NO_CHAR;
                }
                else
                {
                    lexeme[lex_spot] = 0; // null for end of string
                    token_type = LESSER_THAN_OR_EQUAL_TO_TOK;
                    printf("ACCEPT LESSER THAN OR EQUAL TO: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                    state = FINAL;       // leave next_char alone, for next token
                    return token_type;
                }
                break;
            case GREATER_THAN_OR_EQUAL_TO_STATE:
                if (next_char == '=')
                {
                    state = GREATER_THAN_OR_EQUAL_TO_STATE;
                    lexeme[lex_spot++] = next_char;
                    next_char = NO_CHAR;
                }
                else
                {
                    lexeme[lex_spot] = 0; // null for end of string
                    token_type = GREATER_THAN_OR_EQUAL_TO_TOK;
                    printf("ACCEPT GREATER THAN OR EQUAL TO: %s, token type: %d \n", lexeme, token_type);  // This is a final state
                    state = FINAL;       // leave next_char alone, for next token
                    return token_type;
                }
                break;

                //case DEC_FRAC:
                //    if (isdigit(next_char))
                //    {
                //        state = DEC_FRAC;
                //        lexeme[lex_spot++] = next_char;
                //        next_char = NO_CHAR;
                //    }
                //    else
                //    {
                //        lexeme[lex_spot] = 0; // null for end of string
                //        token_type = DECIMAL_FRACTION_TOK;
                //        printf("ACCEPT DECIMAL_FRACTION %s\n", lexeme);  // This is a final state
                //        state = FINAL;       // leave next_char alone, for next token
                //    }
                //    break;


                // I tried to make a newline doe but it didn`t end up working how i wanted it

                //case newline_state:
                //if (next_char == '\n')
                //{
                //    lexeme[lex_spot] = 0; // null for end of string
                //    token_type = newline_tok;
                //    printf("accept newline: %s, token type: %d \n", lexeme, token_type);  // this is a final state
                //    state = final;       // leave next_char alone, for next token
                //}
                //break;

                //

            default:
                printf("INTERNAL ERROR: Illegal state %d\n", state);
                state = FINAL;
                break;

                } // end of switch

            } // end of while state not FINAL STATE

        }  // end of infinite loop

        return 0;  // successful exit code
    }// end of main